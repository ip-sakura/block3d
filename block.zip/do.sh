javac *.java
java Main